from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
from werkzeug.utils import secure_filename
import os
import tempfile
import edge_tts
import asyncio
import base64
from gemini import GeminiResponder

app = Flask(__name__)
CORS(app)

responder = GeminiResponder()

@app.route("/transcribe", methods=["POST"])
def transcribe():
    if "audio" in request.files:
        audio = request.files["audio"]
        filename = secure_filename(audio.filename)
        audio_path = os.path.join(tempfile.gettempdir(), filename)
        audio.save(audio_path)

        with open(audio_path, "rb") as f:
            audio_bytes = f.read()

        transcript = responder.whisper(audio_bytes)
    else:
        transcript = request.form.get("text", "")
        if not transcript:
            return jsonify({"error": "No audio or text provided"}), 400

    response_text = responder.chat(transcript)
    audio_path = asyncio.run(text_to_speech(response_text))

    with open(audio_path, "rb") as f:
        audio_base64 = base64.b64encode(f.read()).decode("utf-8")

    return jsonify({
        "text": response_text,
        "audio": audio_base64
    })

async def text_to_speech(text):
    output_path = os.path.join(tempfile.gettempdir(), "response.mp3")
    communicate = edge_tts.Communicate(text, "ja-JP-NanamiNeural")
    await communicate.save(output_path)
    return output_path

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=10000)