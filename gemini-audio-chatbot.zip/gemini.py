import google.generativeai as genai
import os
import tempfile
import base64
import requests

genai.configure(api_key=os.environ.get("GEMINI_API_KEY"))

class GeminiResponder:
    def __init__(self):
        self.model = genai.GenerativeModel("gemini-1.5-flash")

    def whisper(self, audio_bytes):
        # GeminiではなくWhisper APIなどを想定（ここではダミー）
        return "[音声認識結果]"

    def chat(self, user_input):
        convo = self.model.start_chat(history=[])
        convo.send_message(user_input)
        return convo.last.text